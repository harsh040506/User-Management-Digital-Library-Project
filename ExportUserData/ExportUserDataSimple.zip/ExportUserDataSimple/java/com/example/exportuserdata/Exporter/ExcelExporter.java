package com.example.exportuserdata.Exporter;

import com.example.exportuserdata.Entity.Users;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ExcelExporter {
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private List<Users> listUsers;

    public ExcelExporter(List<Users> listUsers) {
        this.listUsers = listUsers;
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Users");
        writeHeaderLine();
        writeDataLines();
    }

    private void writeHeaderLine() {
        Row row = sheet.createRow(0);
        createCell(row, 0, "User ID");
        createCell(row, 1, "Full Name");
        createCell(row, 2, "Username");
        createCell(row, 3, "Password");
    }

    private void createCell(Row row, int columnCount, Object value) {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        setCellValue(cell, value);
    }

    private void setCellValue(Cell cell, Object value) {
        if (value instanceof Long) {
            cell.setCellValue((Long) value);
        } else if (value instanceof Boolean) {
            cell.setCellValue((Boolean) value);
        } else {
            cell.setCellValue(value.toString());
        }
    }

    private void writeDataLines() {
        int rowCount = 1;

        for (Users user : listUsers) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;

            createCell(row, columnCount++, user.getId());
            createCell(row, columnCount++, user.getFullname());
            createCell(row, columnCount++, user.getUsername());
            createCell(row, columnCount++, user.getPassword());
        }
    }

    public void export(HttpServletResponse response) throws IOException {
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
}