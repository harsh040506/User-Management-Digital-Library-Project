package com.example.exportuserdata.Exporter;

import com.example.exportuserdata.Entity.Users;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

public class PDFExporter {
    private List<Users> listUsers;

    public PDFExporter(List<Users> listUsers) {
        this.listUsers = listUsers;
    }

    private void writeTableHeader(PdfPTable table) {
        table.addCell("User ID");
        table.addCell("Full Name");
        table.addCell("Username");
        table.addCell("Password");
    }

    private void writeTableData(PdfPTable table) {
        for (Users user : listUsers) {
            table.addCell(String.valueOf(user.getId()));
            table.addCell(user.getFullname());
            table.addCell(user.getUsername());
            table.addCell(user.getPassword());
        }
    }

    public void export(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        Paragraph title = new Paragraph("List of Users");
        title.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(title);

        PdfPTable table = new PdfPTable(4);  // 4 columns for Users
        table.setWidthPercentage(100f);
        table.setSpacingBefore(10);

        writeTableHeader(table);
        writeTableData(table);

        document.add(table);
        document.close();
    }
}